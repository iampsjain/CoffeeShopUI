package com.javasampleapproach.pagingjpa.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.javasampleapproach.pagingjpa.model.Customer;
import com.javasampleapproach.pagingjpa.repo.CustomerRepository;

@Service
public class CustomerService {

	private final static int PAGESIZE = 3;
	
	@Autowired
	CustomerRepository repository;
	
	public void save(Customer customer) {
		repository.save(customer);
	}
	
	public Iterable<Customer> findAllCustomers() {
		return repository.findAll();
	}
	
	public List<Customer> getPage(int pageNumber) {
		PageRequest request = new PageRequest(pageNumber - 1, PAGESIZE, Sort.Direction.ASC, "id");
		
		return repository.findAll(request).getContent();
	}
}
