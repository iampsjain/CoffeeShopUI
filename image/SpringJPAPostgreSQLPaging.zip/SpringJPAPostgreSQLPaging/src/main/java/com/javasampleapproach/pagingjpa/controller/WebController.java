package com.javasampleapproach.pagingjpa.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.javasampleapproach.pagingjpa.model.Customer;
import com.javasampleapproach.pagingjpa.service.CustomerService;

@RestController
public class WebController {

	@Autowired
	private CustomerService customerService;

	@RequestMapping("/save")
	public String process() {
		customerService.save(new Customer("Jack", "Smith"));
		customerService.save(new Customer("Adam", "Johnson"));
		customerService.save(new Customer("Kim", "Smith"));
		customerService.save(new Customer("David", "Williams"));
		customerService.save(new Customer("Peter", "Davis"));
		return "Done";
	}

	@RequestMapping("/findall")
	public String findAll() {
		String result = "<html>";

		for (Customer customer : customerService.findAllCustomers()) {
			result += customer.toString() + "<br/>";
		}

		return result + "</html>";
	}

	@RequestMapping(value = "/customers", method = RequestMethod.GET)
	public String viewCustomers(@RequestParam(name = "p", defaultValue = "1") int pageNumber) {
		String result = "<html>";

		List<Customer> customers = customerService.getPage(pageNumber);

		for (Customer customer : customers) {
			result += customer.toString() + "<br/>";
		}

		return result + "</html>";
	}

}
