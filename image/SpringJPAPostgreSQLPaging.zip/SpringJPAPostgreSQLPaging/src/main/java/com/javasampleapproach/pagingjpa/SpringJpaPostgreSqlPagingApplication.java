package com.javasampleapproach.pagingjpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringJpaPostgreSqlPagingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringJpaPostgreSqlPagingApplication.class, args);
	}
}
