package com.javasampleapproach.pagingjpa.repo;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.javasampleapproach.pagingjpa.model.Customer;

public interface CustomerRepository extends PagingAndSortingRepository<Customer, Long> {

}
