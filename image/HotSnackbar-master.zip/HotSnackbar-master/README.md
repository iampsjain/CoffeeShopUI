HOT SNACKBAR
=====================


HotSnackbar is a pure js lightweight material snack-bar.

----------
Demo
-------------
![hotsnackbar gif demo](demo.gif)

Usage
-------------
include
```html
<link href="https://fonts.googleapis.com/css?family=Jaldi" rel="stylesheet">
    	
    <script type="text/javascript" src="hotsnackbar.js"></script>
```

call the snackbar
```javascript
 hotsnackbar('icon_text', 'your text');
```

LICENSE
-------

    nobody_cares_what_you_do_with_it_license

---------

> **know this:**

> - icon_text is defined in the js file and has saparate classes
> - want to add something or improve? be my guest.
> - why hotSnackbar?  i had a fever of 102 when i wrote this, thats why.


